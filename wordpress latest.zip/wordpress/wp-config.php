<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ':7v=W_/O>vMh#W@>DS=aQj8R(}%^drzj@hq1uIPs:DA<A~}_tJV*O!ziSo}0nE.l');
define('SECURE_AUTH_KEY',  'b!:MU<>4sRTYMI^1?:s3R^{I%.[gF}]/T%d8$FQ,&-y*eslp#Ed{9}1}2<yP,fEG');
define('LOGGED_IN_KEY',    'pH}Elhn-{55?|f^8!,`O=sUR~UyI^ElYN7#eu$<j>(u,m063+`(b6mB6X)!VwJS~');
define('NONCE_KEY',        'pBujVk@v.1Td6J:r<qH4&_K%k&5q!]Hn{h5yjM8t7,-Hu):c[B60dV4/@24?&aPB');
define('AUTH_SALT',        'z<J!/YfU0[xv?6v^/C~1By&o[(&1=kU$=Gn)3CkAXI:H_%oG]#zujrZxya?0-m>S');
define('SECURE_AUTH_SALT', '`TzN5-7=c,&^gWrq5^Pis@dK(F7FRAkvc#diU7})@DqzSA/^E@^ZGa?`[?ug*XU]');
define('LOGGED_IN_SALT',   'Bsb[2Zvu5e,!Ck^*XNq1w^f2-XkS}~xLMV6 Lf]YO`RwL%vF%`bR?PAjU2~=<?/e');
define('NONCE_SALT',       'jPx5+DBfGoZew=ylYvA^j.;*C?WLY[M#[I5et<eI(gp8e2qz#I=v,Uzk@4B5kT01');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
